# Manual Testing Project – Magic Number Guess Game

This project contains the complete manual testing documentation for a web-based **Magic Number Guessing Game** created using JavaScript.

## 🔍 Project Overview
The objective of this project is to manually test the functionality, input validation, and user interactions of the Magic Number Game. The testing process involved creating test scenarios, test cases, identifying bugs, and summarizing the results.

## 📂 Files Included

- **Test_Scenarios.xlsx** – High-level test scenarios
- **Test_Cases_MagicGame.xlsx** – Step-by-step test cases with expected outcomes
- **Bug_Report_MagicGame.xlsx** – Bugs found during testing with severity and status
- **Test_Summary_Report.docx** – Final summary of the testing process

## 🧪 Testing Details

- **Testing Type:** Manual Testing
- **Modules Tested:** Input validation, Game logic, UI feedback
- **Tools Used:** Microsoft Excel, Browser, GitHub Pages
- **Tested By:** Anshika

## ✅ Test Result Summary

- **Total Test Cases:** 10
- **Passed:** 7
- **Failed:** 3
- **Bugs Found:** 3 (1 High, 1 Medium, 1 Low)
- **Status:** Completed

## 🔗 Live Game Link

You can play the tested game here:  
[Magic Number Guess Game on GitHub Pages](https://anshi2507-hub.github.io/Magic-Number-Guess-Game/)

---

**Note:** This repository is part of a portfolio project to demonstrate manual testing skills for web applications.
